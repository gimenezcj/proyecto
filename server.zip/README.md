![UTN FRLP](/assets/images/logo-frlp-escalado.png)
# Codapli - GAMA
Proyecto para la materia Proyecto
ciclo lectivo 2022

Aplicativo Server

Realizado en Node.js

Instalacion de los modulos necesarios:
Importante a tener en cuenta las versiones que se han utilizado para compatibilidad de las librerias:
 - node.js v16.17.0.
 - npm 8.15.0

Comando:

> 1. npm install
> 2. npm start

Modulos utilizados en el desarrollo:

