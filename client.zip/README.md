![UTN FRLP](/assets/images/logo-frlp-escalado.png)
# Codapli - GAMA
Proyecto para la materia Proyecto
ciclo lectivo 2022

Aplicativo Client

Realizado en React

Instalacion de los modulos necesarios:
Importante a tener en cuenta las versiones que se han utilizado para compatibilidad de las librerias:
 - node.js v16.17.0.
 - npm 8.15.0

Comando:

> 1. npm install
> 2. npm start

Modulos utilizados en el desarrollo:

> * react-bootstrap@2.5.0
> * react-icons@4.4.0
> * react-router-dom@6.3.0
> * expo-gl@11.4.0
> * three@0.143.0