import React from "react";

export default function DatosPersonales ({paciente,setPaciente})  {
  return (
    <></>
  );
}