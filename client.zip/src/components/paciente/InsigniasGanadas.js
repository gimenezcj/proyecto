import React from "react";

function InsigniasGanadas ({valija}) {
  return (
    <>
      <h4>Insignias ganadas</h4>
    </>
  );
}

export default InsigniasGanadas;